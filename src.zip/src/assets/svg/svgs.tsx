import OnBone from './onb1.svg';
import Onb from './ooo.png';



export default {
OnBone,
Onb
}